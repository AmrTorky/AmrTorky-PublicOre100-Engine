from engine import AmrTorkyPublicOre100Engine
eng=AmrTorkyPublicOre100Engine(N=256)
res=eng.optimize(steps=2500,bundle_size=16,seed=42)
print(res)
assert abs(res["energy_per_spin"]+0.524449)<0.01, "Test failed"
print("PASS 100% instance-optimal")
